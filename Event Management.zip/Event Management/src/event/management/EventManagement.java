package event.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class EventManagement extends JFrame {
    private JTextField eventNameField, eventLocationField, eventDateField;
    private JTextArea eventDescriptionField;
    private JButton addEventButton, viewEventsButton, resetButton, updateEventButton, deleteEventButton;
    private JTable eventsTable;
    private DefaultTableModel tableModel;
    private int selectedEventId = -1;

    public EventManagement() {
        setTitle("Event Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        setVisible(true);
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        JLabel titleLabel = new JLabel("Event Management System", JLabel.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Event Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Event Name:"), gbc);
        gbc.gridx = 1;
        eventNameField = new JTextField(20);
        formPanel.add(eventNameField, gbc);

        // Event Location
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Event Location:"), gbc);
        gbc.gridx = 1;
        eventLocationField = new JTextField(20);
        formPanel.add(eventLocationField, gbc);

        // Event Date
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Event Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        eventDateField = new JTextField(20);
        formPanel.add(eventDateField, gbc);

        // Event Description
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Event Description:"), gbc);
        gbc.gridx = 1;
        eventDescriptionField = new JTextArea(3, 20);
        formPanel.add(new JScrollPane(eventDescriptionField), gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 5, 5));
        addEventButton = new JButton("Add Event");
        buttonPanel.add(addEventButton);
        resetButton = new JButton("Reset Form");
        buttonPanel.add(resetButton);
        updateEventButton = new JButton("Update Event");
        buttonPanel.add(updateEventButton);
        deleteEventButton = new JButton("Delete Event");
        buttonPanel.add(deleteEventButton);
        viewEventsButton = new JButton("View Events");
        buttonPanel.add(viewEventsButton);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.WEST);

        // Table panel
        tableModel = new DefaultTableModel(new String[]{"Event ID", "Event Name", "Event Date", "Event Location", "Event Description"}, 0);
        eventsTable = new JTable(tableModel);
        eventsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(eventsTable), BorderLayout.CENTER);

        // Button actions
        addEventButton.addActionListener(e -> addEvent());
        resetButton.addActionListener(e -> resetForm());
        viewEventsButton.addActionListener(e -> viewEvents());
        updateEventButton.addActionListener(e -> updateEvent());
        deleteEventButton.addActionListener(e -> deleteEvent());
        eventsTable.getSelectionModel().addListSelectionListener(e -> selectEvent());
    }

    private void addEvent() {
        String eventName = eventNameField.getText().trim();
        String eventLocation = eventLocationField.getText().trim();
        String eventDate = eventDateField.getText().trim();
        String eventDescription = eventDescriptionField.getText().trim();

        if (eventName.isEmpty() || eventLocation.isEmpty() || eventDate.isEmpty() || eventDescription.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.connect()) {
            String query = "INSERT INTO events (event_name, event_date, event_location, event_description) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, eventName);
                stmt.setString(2, eventDate);
                stmt.setString(3, eventLocation);
                stmt.setString(4, eventDescription);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Event added successfully!");
                resetForm();
                viewEvents();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error adding event: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewEvents() {
        tableModel.setRowCount(0);
        try (Connection conn = DatabaseConnection.connect()) {
            String query = "SELECT * FROM events";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("event_id"),
                        rs.getString("event_name"),
                        rs.getDate("event_date"),
                        rs.getString("event_location"),
                        rs.getString("event_description")
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving events: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateEvent() {
        if (selectedEventId == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to update.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String eventName = eventNameField.getText().trim();
        String eventLocation = eventLocationField.getText().trim();
        String eventDate = eventDateField.getText().trim();
        String eventDescription = eventDescriptionField.getText().trim();

        if (eventName.isEmpty() || eventLocation.isEmpty() || eventDate.isEmpty() || eventDescription.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.connect()) {
            String query = "UPDATE events SET event_name = ?, event_date = ?, event_location = ?, event_description = ? WHERE event_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, eventName);
                stmt.setString(2, eventDate);
                stmt.setString(3, eventLocation);
                stmt.setString(4, eventDescription);
                stmt.setInt(5, selectedEventId);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Event updated successfully!");
                resetForm();
                viewEvents();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error updating event: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteEvent() {
        if (selectedEventId == -1) {
            JOptionPane.showMessageDialog(this, "Please select an event to delete.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.connect()) {
            String query = "DELETE FROM events WHERE event_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, selectedEventId);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Event deleted successfully!");
                resetForm();
                viewEvents();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting event: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void selectEvent() {
        int selectedRow = eventsTable.getSelectedRow();
        if (selectedRow != -1) {
            selectedEventId = (int) tableModel.getValueAt(selectedRow, 0);
            eventNameField.setText((String) tableModel.getValueAt(selectedRow, 1));
            eventDateField.setText(tableModel.getValueAt(selectedRow, 2).toString());
            eventLocationField.setText((String) tableModel.getValueAt(selectedRow, 3));
            eventDescriptionField.setText((String) tableModel.getValueAt(selectedRow, 4));
        }
    }

    private void resetForm() {
        eventNameField.setText("");
        eventLocationField.setText("");
        eventDateField.setText("");
        eventDescriptionField.setText("");
        selectedEventId = -1;
    }
}
